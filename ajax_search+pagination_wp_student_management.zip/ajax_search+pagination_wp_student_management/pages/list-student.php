<style>
    /**********************************************************/
    /* Card layout style */
    .sms-plugin.card {
        max-width: 1500px;
        margin: 0 auto;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
        font-family: Arial, sans-serif;
    }

    .card h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    /* Table style */
    .table-container {
        overflow-x: auto;
        width: 100%; /* Adjust as needed */
        padding: 10px;
    }

    .student-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 16px;
    }

    .student-table th,
    .student-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .student-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }

    /* Button style */
    .btn-edit,
    .btn-delete,
    .btn-view {
        display: inline-block;
        padding: 8px 16px;
        margin: 4px;
        text-decoration: none;
        border-radius: 5px;
        color: #fff;
        cursor: pointer;
        transition: background-color 0.3s;
        border: none;
        font-weight: bold;
        text-transform: uppercase;
        outline: none;
    }

    .btn-edit {
        background-color: #28a745;
    }

    .btn-delete {
        background-color: #dc3545;
    }

    .btn-view {
        background-color: #007bff;
    }

    .btn-edit:hover,
    .btn-delete:hover,
    .btn-view:hover {
        opacity: 0.8;
    }

    .display-success {
        background-color: #d4edda;
        border-color: #c3e6cb;
        color: #155724;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 4px;
    }

    .sms-plugin.card {
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
}

.display-success {
    color: green;
    margin-bottom: 10px;
}

.search-container {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 10px;
}

#search {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.table-container {
    position: relative;
}

.student-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.student-table th, .student-table td {
    padding: 10px;
    border: 1px solid #ddd;
}

.student-table thead {
    background-color: #f2f2f2;
}

.pagination-container {
    display: flex;
    justify-content: flex-end;
    margin-top: 10px;
}

#prev-btn, #next-btn {
    padding: 10px 20px;
    border: 1px solid #ccc;
    background-color: #f9f9f9;
    border-radius: 5px;
    cursor: pointer;
    margin-left: 5px;
}

#prev-btn {
    background-color: #d9534f; /* Bootstrap danger color */
    color: white;
    border: none;
}

#next-btn {
    background-color: #5cb85c; /* Bootstrap success color */
    color: white;
    border: none;
}
#prev-btn:hover, #next-btn:hover {
    opacity: 0.8;
}

    /**********************************************************/
</style>

<div class="sms-plugin card">
    <h2>List Student</h2>

    <?php if (!empty($displayMessage)) { ?>
    <div class="display-success">
        <?php echo $displayMessage; ?>
    </div>
    <?php } ?>

    <div class="search-container">
        <input type="text" id="search" placeholder="Search by Name or Email">
    </div>
    <div class="table-container">
        <table class="student-table">
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>#Name</th>
                    <th>#Email</th>
                    <th>#Profile</th>
                    <th>#Gender</th>
                    <th>#Phone</th>
                    <th>#Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Rows will be appended here via JavaScript -->
            </tbody>
        </table>
        <div class="pagination-container">
            <button id="prev-btn" disabled>Previous</button>
            <button id="next-btn">Next</button>
        </div>
    </div>
</div>

