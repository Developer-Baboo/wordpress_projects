<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_student_management' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '`cyee`85Guw;!bY^E~errH4jY.Hd=GsZ=R%3AAKUN*`q*!+&<ko@{Fi+F~.IgdJ+' );
define( 'SECURE_AUTH_KEY',  'S&Rh!JSTDW&j-dS8}rU2if3N;iUUMa9Ue%,.bfgmYu,+*68B|0d68Hq^c*y|Ff7z' );
define( 'LOGGED_IN_KEY',    '9QJP;|zvOenN*Jp{<Ih($[7I|IX9nFhDDfDVUo7g&+f~ZKP)yhb-9sa<wDBo<x72' );
define( 'NONCE_KEY',        '5Z%.7?Q3<:~@3^EKASFGDWUK/dZ>AUm e{|OvZUwz3 }+|,G%Q@eX5Q{]0<c7IRY' );
define( 'AUTH_SALT',        '-nM0<j}qk|;j0c7D9HjciU&{gwStt[aN!z.SN^*I:ac=:2^u,<~:$mmc~vO}Bl_[' );
define( 'SECURE_AUTH_SALT', '#MgzkpL]2,>}VlC1H^!TI%%#j{:C[pvEC8>`GP`/1rfdDub rtfCiCDNT`dKalqj' );
define( 'LOGGED_IN_SALT',   'UG}4O~B2(O%*nFQ(*a3]K/!=yeYa4dv]Z}3 3hz[4GAWl-~q73RKce-/7D{f1vqM' );
define( 'NONCE_SALT',       ')Y&7;ER=W4Ohv6T7@OW38uCBfBB)0hd3zcz#v7gY3laT)4Aew?HCBzko.q8,/aoV' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
