<?php 
/**
* Plugin Name: Student Management System
* Plugin URI: https://www.your-site.com/
* Description: My Plugin to explain curd functionality
* Version: 0.1
* Author: Baboo Kumar
* Author URI: https://www.your-site.com/
**/

define("SMS_PLUGIN_PATH", plugin_dir_path(__FILE__));
define("SMS_PLUGIN_URL", plugin_dir_url(__FILE__));
define("SMS_PLUGIN_BASENAME", plugin_basename(__FILE__));
/* echo SMS_PLUGIN_BASENAME;
die; */

include_once SMS_PLUGIN_PATH.'class/StudentManagement.php';

$studentManageObject = new StudentManagement();

register_activation_hook(__FILE__, array($studentManageObject, "createStudentTable"));

register_deactivation_hook(__FILE__, array($studentManageObject, "dropStudentTable"));
?>