<?php 

class StudentManagement{
    
    // Member variables

    private $message = "";
    private $status = "";
    private $action =  "";

    //constructor 
    public function __construct(){
        add_action("admin_menu", array($this, "addAdminMenus"));
        add_action("admin_enqueue_scripts", array($this, "addStudentPluginFiles"));
        add_filter("plugin_action_links_".SMS_PLUGIN_BASENAME, array($this, "plugin_settings_link"));



// we instruct hum kuch ajax request fire kr rha han ap usa handle kro
        add_action("wp_ajax_sms_ajax_handler", array($this, "sms_ajax_handler"));

        // add_action("wp_ajax_sms_ajax_handler", array($this, "sms_ajax_handler"));


    }

    // Add Setting links
    public function plugin_settings_link($links){

        $settings_link = '<a href="options-general.php?page=sms-plugin-settings">Settings</a>';
        array_unshift($links, $settings_link);
        
        return $links;
     }

     /* Ajax Request Handler  */
     public function sms_ajax_handler() {
        global $wpdb;
        $table_prefix = $wpdb->prefix; // wp_
    
        if (isset($_REQUEST['param'])) {
            if ($_REQUEST['param'] == "save_form") {
                if (isset($_POST['wp_nonce_add_student']) && wp_verify_nonce($_POST['wp_nonce_add_student'], "wp_nonce_add_student")) {
                    // Nonce verified
    
                    $name = sanitize_text_field($_POST['name']);
                    $email = sanitize_text_field($_POST['email']);
                    $gender = sanitize_text_field($_POST['gender']);
                    $phone = sanitize_text_field($_POST['phone']);
                    $profile_url = sanitize_text_field($_POST['profile_url']);
                    $operation_type = sanitize_text_field($_POST['operation_type']);
                    if($operation_type == "edit"){
                        // Edit operation
                        $student_id = $_REQUEST['student_id'];
                        $wpdb->update("{$table_prefix}student_system", array(
                           "name" => $name,
                           "email" => $email,
                           "phone_no" => $phone,
                           "gender" => $gender,
                           "profile_image" => $profile_url,
                        ), array(
                           "id" => $student_id
                        ));
      
                        echo json_encode(array(
                           "status" => 1,
                           "message" => "Student updated successfully",
                           "data" => []
                        ));
    
                     }else if($operation_type == "add"){
                        $wpdb->insert("{$table_prefix}student_system", array(
                            "name" => $name,
                            "email" => $email,
                            "gender" => $gender,
                            "profile_image" => $profile_url,
                            "phone_no" => $phone
                        ));
        
                        $student_id = $wpdb->insert_id;
        
                        if ($student_id > 0) {
                            // Data created
                            echo json_encode(array(
                                "status" => 1,
                                "message" => "Student saved successfully",
                                "data" => []
                            ));
                        } else {
                            // Failed to create data
                            echo json_encode(array(
                                "status" => 0,
                                "message" => "Failed to add student",
                                "data" => []
                            ));
                        }
                     }
                    
                }
            } elseif ($_REQUEST['param'] == "load_students") {
                $students = $wpdb->get_results("SELECT * FROM {$table_prefix}student_system", ARRAY_A);
    
                if (count($students) > 0) {
                    echo json_encode([
                        "status" => 1,
                        "message" => "Students data",
                        "data" => $students
                    ]);
                } else {
                    echo json_encode([
                        "status" => 0,
                        "message" => "No student found",
                        "data" => []
                    ]);
                }
            }elseif($_REQUEST['param'] == "delete_student"){

                $student_id = $_REQUEST['student_id'];
   
                // Delete action
                $wpdb->delete("{$table_prefix}student_system", array(
                  "id" => $student_id
                ));
   
                echo json_encode(array(
                  "status" => 1,
                  "message" => "Student deleted successfully"
                ));
             }
            else {
                echo json_encode([
                    "status" => 0,
                    "message" => "Invalid request",
                    "data" => []
                ]);
            }
        } else {
            echo json_encode([
                "status" => 0,
                "message" => "No parameter set",
                "data" => []
            ]);
        }
        wp_die();
    }
    

    /* Ends ... */


    // Add Student Plugin Menus and Submenus
    public function addAdminMenus(){

        // Plugin menu
        add_menu_page("Student System", "Student System", "manage_options", "student-system", array($this, "listStudentCallback"), "dashicons-admin-home");

        // Plugin submenu
        add_submenu_page("student-system", "List Student", "List Student", "manage_options", "student-system", array($this, "listStudentCallback"));

        // Plugin submenu
        add_submenu_page("student-system", "Add Student", "Add Student", "manage_options", "add-student", array($this, "addStudentCallback"));

        // Setttings page submenu inside Settings Menu
       add_options_page("SMS Plugin Settings", "SMS Plugin Settings", "manage_options", "sms-plugin-settings", array($this, "sms_plugin_action_handle"));

    }

     // plugin action handler

     public function sms_plugin_action_handle(){
        echo "<h3>SMS Plugin Settings<h3>";
        include_once SMS_PLUGIN_PATH.'pages/sms-plugin-settings.php';
     }
     
     // List Student call back
     public function listStudentCallback(){
        global $wpdb;
    
        // Initialize action
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        $student = [];
    
        if ($action == "edit") {
            $student_id = $_GET['id'];
            $table_prefix = $wpdb->prefix;

            if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btn_submit'])){
                /* echo "<pre>";
                    print_r($_POST);
                die; */
                $name = sanitize_text_field($_POST['name']);
                $email = sanitize_text_field($_POST['email']);
                $gender = sanitize_text_field($_POST['gender']);
                $phone = sanitize_text_field($_POST['phone']);


                $wpdb->update("{$table_prefix}student_system", array(
                    "name" => $name,
                    "email" => $email, 
                    "gender" => $gender,
                    "phone_no" =>$phone
                ), array(
                    "id" => $student_id
                ));

                $this->message = "Student Updated Successfully";            
            }
            $student = $this->getStudentData($student_id);
            $displayMessage = $this->message;
            
            
            include_once SMS_PLUGIN_PATH . 'pages/add-student.php';
        } else if($action == "view"){
            $action = isset($_GET['action']) ? $_GET['action'] : '';
            $student_id = $_GET['id'];
            $student = $this->getStudentData($student_id);
            // View single student data 
            include_once SMS_PLUGIN_PATH . 'pages/add-student.php';
        }else {

            global $wpdb;
            $table_prefix = $wpdb->prefix;
            if($action == "delete"){
                $data = $this->getStudentData(intval($_GET['id']));
                if(!empty($data)){
                    $student_id = $_GET['id'];
                    $wpdb->delete("{$table_prefix}student_system", array(
                        "id" => $student_id
                    ));
                    $this->message = "Student Deleted Successfully";
                }else{
                    // no action
                }
            }

            $table_prefix = $wpdb->prefix;
            $students = $wpdb->get_results("SELECT * FROM {$table_prefix}student_system", ARRAY_A);
            $displayMessage = $this->message;
            include_once SMS_PLUGIN_PATH . 'pages/list-student.php';
        }
    }
    
    // return Student Data
    private function getStudentData($student_id){
        global $wpdb;
        $table_prefix = $wpdb->prefix;
        $student = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM  {$table_prefix}student_system WHERE id = %d", $student_id),
            ARRAY_A
        );
        return $student;
    }
    
     // Add Student Page
     public function addStudentCallback(){
        
        // Form Submission Code
        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btn_submit']) )
        {
            // Nonce Verification
            if(isset($_POST['wp_nonce_add_student']) && wp_verify_nonce($_POST['wp_nonce_add_student'], "wp_nonce_add_student" ) ){

                // Success

                $this->saveStudentFormData();
            }else{

                // Failure
                $this->message = "Verification failed";
                $this->status = 0;
            }
        }

        $displayMessage = $this->message;
        $displayStatus = $this->status;

        // echo "<h3>Welcome to student add page</h3>";
        include_once SMS_PLUGIN_PATH .'pages/add-student.php';
     }


    //  Save Student Form Data
    public function saveStudentFormData(){
        // echo "<pre>";
        // print_r($_POST);


        global $wpdb;
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_text_field($_POST['email']);
        $gender = sanitize_text_field($_POST['gender']);
        $phone = sanitize_text_field($_POST['phone']);
        $profile_url = sanitize_text_field($_POST['profile_url']);

        /* $sql = "INSERT INTO `".$wpdb->prefix."student_system` (`name`, `email`, `gender`, `phone_no`) VALUES ('$name', '$email', '$gender', '$phone')";
        $wpdb->query($sql); */


        $table_prefix = $wpdb->prefix;

        $inserted = $wpdb->insert(
            "{$table_prefix}student_system",
            array(
                "name" => $name,
                "email" => $email,
                "gender" => $gender,
                "phone_no" => $phone,
                "profile_image" => $profile_url,
                "created_at" => date("Y-m-d H:i:s")
            )
        );

        // $student_id = $wpdb->insert_id();
        if ($inserted) {
            $this->message = "Student saved successfully";
            $this->status = 1; 
        }else{
            $this->message = "Student failed to save";
            $this->status = 0;
        }
    }


    
     //  Create Table structure
    public function createStudentTable(){
        global $wpdb;
        $prefix = $wpdb->prefix;

        $sql = '
        CREATE TABLE `'.$prefix.'student_system` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(255) NOT NULL,
            `email` varchar(255) NOT NULL,
            `gender` enum("male","female","other") NOT NULL,
            `phone_no` varchar(255) NOT NULL,
            `profile_image` varchar(255) NOT NULL
            `created_at` timestamp NULL DEFAULT NULL,
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
          
        ';

        include_once ABSPATH. 'wp-admin/includes/upgrade.php';

        dbDelta($sql); 
    }

    // Drop Table structure from database
     // Drop Student Table
     public function dropStudentTable(){

        global $wpdb;

        $prefix = $wpdb->prefix; // wp_

        // // Table Data Backup
        // $db_user = DB_USER;
        // $db_password = DB_PASSWORD;
        // $db_name = DB_NAME;
        // $wp_content_path = WP_CONTENT_DIR; 

        // $version = time();
        // $filename = "sms-db-tables-".$version.".sql";

        // $backup_path = $wp_content_path."/sms-plugin/".$filename;

        // // Tables
        // $tables = ["{$wpdb->prefix}student_system"];

        // $tables_names = implode(" ", $tables);

        // if(!is_dir($wp_content_path."/sms-plugin")){

        //     mkdir($wp_content_path."/sms-plugin", 0777);
        // }

        // // Shell Execute command
        // shell_exec("mysqldump -u {$db_user} -p{$db_password} {$db_name} $tables_names > {$backup_path}");

        // // mysqldump -u root -pAdmin@123 db_name table_name1 table_name2 


        $sql = "DROP TABLE IF EXISTS ".$prefix."student_system";

        $wpdb->query($sql);
     }




    //  Add Plugin File
    public function addStudentPluginFiles(){

        // style
        wp_enqueue_style("datatable-css", SMS_PLUGIN_URL . "assets/css/dataTables.dataTables.min.css", array(), "1.0", "all");
                // Message Plugin
        wp_enqueue_style("toastr-css", SMS_PLUGIN_URL . "assets/css/toastr.min.css", array(), "1.0", "all");
        wp_enqueue_style("custom-css", SMS_PLUGIN_URL . "assets/css/custom.css", array(), "1.0", "all");

        // Script
        wp_enqueue_media();
        wp_enqueue_script("datatable-js", SMS_PLUGIN_URL . "assets/js/dataTables.min.js", array("jquery"), "1.0");
        // Message Plugin
        wp_enqueue_script("toastr-js", SMS_PLUGIN_URL . "assets/js/toastr.min.js", array("jquery"), "1.0");
        wp_enqueue_script("script-js", SMS_PLUGIN_URL . "assets/js/script.js", array("jquery"), "1.0");



        // pass ajax url, jis ko hum use krenga ajax request complete krna kaleya
        $data = "var sms_ajax_url = '".admin_url('admin-ajax.php')."';";
        wp_add_inline_script("script-js", $data);


    }
}

?>