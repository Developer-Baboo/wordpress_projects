jQuery(document).ready(function($) {
    console.log("Hello Js");

    // Initialize DataTable
    let table = new DataTable('#tbl-student-table');

    // Event handler for profile upload button
    $("#btn-upload-profile").on("click", function(event){
        event.preventDefault();

        // Create media instance (object)
        let mediaUploader = wp.media({
            title: "Select Profile Image",
            button: {
                text: "Use this image"
            },
            multiple: false
        });

        // Handle image selection
        mediaUploader.on("select", function(){
            let attachment = mediaUploader.state().get("selection").first().toJSON();
            // console.log(attachment);
            // Update input field with the URL of the selected image
            $('#profile_url').val(attachment.url);
        });

        // Open media modal
        mediaUploader.open();
    });

    // Form Submit Code
    $("#btn_sm_form").on("click", function(event){
        event.preventDefault();

        var formData = $("#frm_sms_form").serialize() +
         "&action=sms_ajax_handler&param=save_form";

        // ajax request
        $.ajax({
            url: sms_ajax_url, //Jahn hum data ko submit krvana chahta han
            data: formData,
            method: "POST",
            success: function (response) {
                // Success response
                // console.log(response);
                var data = JSON.parse(response);
                if(data.status){
                    toastr.success(data.message);
                    setTimeout(function() {
                        location.reload()
                    }, 2000);
                }else{
                    toastr.error(data.message);
                    setTimeout(function() {
                        location.reload()
                    }, 2000);
                }
            },
            error: function(response) {
                // Error response
            }
        });
    });
    
    // load funciton sirf table pa call ho naka hr page pa
    if ($("#tbl-student-table").length > 0) {

        load_students();
    }


    // Event delegation for delete button
    $(document).on("click", ".btn-student-delete", function(event){
        event.preventDefault();
        if (confirm("Are you sure want to delete?")) {
            var student_id = $(this).attr("data-id");
            var formData = "action=sms_ajax_handler&param=delete_student&student_id=" + student_id;

            $.ajax({
                url: sms_ajax_url,
                data: formData,
                method: "POST",
                success: function(response) {
                    // console.log("Raw Response:", response);
                    try {
                        var data = JSON.parse(response);
                        if (data.status) {
                            toastr.success(data.message);
                            load_students(); // Reload students after deletion
                        } else {
                            toastr.error(data.message);
                        }
                    } catch (error) {
                        toastr.error("An error occurred while parsing the response.");
                        console.error("Parsing error:", error);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                }
            });
        }
    });
    
    // Fetch Student Table
    function load_students() {
        var formData = "action=sms_ajax_handler&param=load_students";
        var studentHTML = "";

        // / Destroy existing DataTable instance before making a new AJAX call
        if ($.fn.DataTable.isDataTable('#tbl-student-table')) {
            $('#tbl-student-table').DataTable().destroy();
        }

        $.ajax({
            url: sms_ajax_url, // Use the localized variable
            data: formData,
            method: "GET",
            success: function(response) {
                var data = JSON.parse(response);
                console.log("Raw Response:", response);

                if (data.status) {
                    $.each(data.data, function(index, student) {
                        studentHTML += "<tr>";
                        studentHTML += "<td>" + student.id + "</td>";
                        studentHTML += "<td>" + student.name + "</td>";
                        studentHTML += "<td>" + student.email + "</td>";
                        studentHTML += '<td><img style="height:100px;width:100px" src="' + student.profile_image + '"/></td>';
                        studentHTML += "<td>" + student.gender + "</td>";
                        studentHTML += "<td>" + student.phone_no + "</td>";
                        studentHTML += '<td><a href="admin.php?page=student-system&action=edit&id=' + student.id + '" class="btn-edit">Edit</a> <a class="btn-view" href="admin.php?page=student-system&action=view&id=' + student.id + '">View</a> <a class="btn-delete btn-student-delete" data-id="' + student.id + '">Delete</a></td>';
                        studentHTML += "</tr>";
                    });

                    $("#tbl-student-table tbody").html(studentHTML);
                    $("#tbl-student-table").DataTable();
                } else {
                    toastr.error(data.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            }
        });

        // Delete function
        /* $(document).on("click", ".btn-student-delete", function() {
            if (confirm("Are you sure want to delete?")) {
                var student_id = $(this).attr("data-id");
                var deleteFormData = "action=sms_ajax_handler&param=delete_student&student_id=" + student_id;

                $.ajax({
                    url: sms_vars.sms_ajax_url,
                    data: deleteFormData,
                    method: "POST",
                    success: function(response) {
                        var data = JSON.parse(response);

                        if (data.status) {
                            toastr.success(data.message);
                            setTimeout(function() {
                                load_students(); // Reload students after deletion
                            }, 3000);
                        } else {
                            toastr.error(data.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        toastr.error('An error occurred: ' + error);
                    }
                });
            }
        }); */
    }


     // Delete function
    /* $(".btn-student-delete").on("click", function(event){
        if (confirm("Are you sure want to delete?")) { // true

            var student_id = $(this).attr("data-id");

            var formData = "action=sms_ajax_handler&param=delete_student&student_id=" + student_id;

            $.ajax({
                url: sms_ajax_url,
                data: formData,
                method: "POST",
                success: function(response) {

                    var data = jQuery.parseJSON(response);

                    toastr.success(data.message);

                    // setTimeout(function() {
                    //     location.reload()
                    // }, 3000);
                },
                error: function() {

                }
            });
        }
    }); */


});
