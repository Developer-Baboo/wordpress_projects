jQuery(document).ready(function($) {
    console.log("Hello Js");

    // Event handler for profile upload button
    $("#btn-upload-profile").on("click", function(event){
        event.preventDefault();

        // Create media instance (object)
        let mediaUploader = wp.media({
            title: "Select Profile Image",
            button: {
                text: "Use this image"
            },
            multiple: false
        });

        // Handle image selection
        mediaUploader.on("select", function(){
            let attachment = mediaUploader.state().get("selection").first().toJSON();
            // Update input field with the URL of the selected image
            $('#profile_url').val(attachment.url);
        });

        // Open media modal
        mediaUploader.open();
    });

    $("#search").on("keyup", function(event){
        var searchTerm = $(this).val();

        // Check if search term meets the minimum limit
        if (searchTerm.length >= 3 || searchTerm.length === 0) {
            // Call the search function
            searchStudents(searchTerm);
        }
    });

    // Form Submit Code
    $("#btn_sm_form").on("click", function(event){
        event.preventDefault();

        var formData = $("#frm_sms_form").serialize() +
         "&action=sms_ajax_handler&param=save_form";

        // ajax request
        $.ajax({
            url: sms_ajax_url,
            data: formData,
            method: "POST",
            success: function (response) {
                // Success response
                var data = JSON.parse(response);
                if(data.status){
                    toastr.success(data.message);
                    setTimeout(function() {
                        location.reload()
                    }, 2000);
                }else{
                    toastr.error(data.message);
                    setTimeout(function() {
                        location.reload()
                    }, 2000);
                }
            },
            error: function(response) {
                // Error response
            }
        });
    });

    // load function sirf table pa call ho naka hr page pa
    if ($(".student-table").length > 0) {
        load_students();
    }

    // Event delegation for delete button
    $(document).on("click", ".btn-student-delete", function(event){
        event.preventDefault();
        if (confirm("Are you sure want to delete?")) {
            var student_id = $(this).attr("data-id");
            var formData = "action=sms_ajax_handler&param=delete_student&student_id=" + student_id;

            $.ajax({
                url: sms_ajax_url,
                data: formData,
                method: "POST",
                success: function(response) {
                    try {
                        var data = JSON.parse(response);
                        if (data.status) {
                            toastr.success(data.message);
                            load_students(); // Reload students after deletion
                        } else {
                            toastr.error(data.message);
                        }
                    } catch (error) {
                        toastr.error("An error occurred while parsing the response.");
                        console.error("Parsing error:", error);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                }
            });
        }
    });

    // Fetch Student Table
    function load_students() {
        var formData = {
            action: 'sms_ajax_handler',
            param: 'load_students'
        };

        $.ajax({
            url: sms_ajax_url,
            data: formData,
            method: "GET",
            success: function(response) {
                try {
                    var data = JSON.parse(response);
                    if (data.status) {
                        var studentHTML = "";
                        $.each(data.data, function(index, student) {
                            studentHTML += "<tr>";
                            studentHTML += "<td>" + student.id + "</td>";
                            studentHTML += "<td>" + student.name + "</td>";
                            studentHTML += "<td>" + student.email + "</td>";
                            studentHTML += '<td><img style="height:100px;width:100px" src="' + student.profile_image + '"/></td>';
                            studentHTML += "<td>" + student.gender + "</td>";
                            studentHTML += "<td>" + student.phone_no + "</td>";
                            studentHTML += '<td><a href="admin.php?page=student-system&action=edit&id=' + student.id + '" class="btn-edit">Edit</a> <a class="btn-view" href="admin.php?page=student-system&action=view&id=' + student.id + '">View</a> <a class="btn-delete btn-student-delete" data-id="' + student.id + '">Delete</a></td>';
                            studentHTML += "</tr>";
                        });

                        $(".student-table tbody").html(studentHTML);
                    } else {
                        toastr.error(data.message);
                    }
                } catch (e) {
                    console.error("Failed to parse JSON response:", e);
                    toastr.error('Failed to load students data.');
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            }
        });
    }

    //  // Search button click event
    //  $("#search-btn").on("click", function(event){
    //     event.preventDefault();
    //     var searchTerm = $("#search-input").val();
    //     if (searchTerm.trim() !== '') {
    //         searchStudents(searchTerm);
    //     }
    // });

    // Search function
    function searchStudents(searchTerm) {
        var formData = {
            action: 'sms_ajax_handler',
            param: 'search_students',
            search_term: searchTerm
        };

        $.ajax({
            url: sms_ajax_url,
            data: formData,
            method: "GET",
            success: function(response) {
                console.log("Search Result:", response);
                try {
                    var data = JSON.parse(response);
                    if (data.status) {
                        var studentHTML = "";
                        $.each(data.data, function(index, student) {
                            studentHTML += "<tr>";
                            studentHTML += "<td>" + student.id + "</td>";
                            studentHTML += "<td>" + student.name + "</td>";
                            studentHTML += "<td>" + student.email + "</td>";
                            studentHTML += '<td><img style="height:100px;width:100px" src="' + student.profile_image + '"/></td>';
                            studentHTML += "<td>" + student.gender + "</td>";
                            studentHTML += "<td>" + student.phone_no + "</td>";
                            studentHTML += '<td><a href="admin.php?page=student-system&action=edit&id=' + student.id + '" class="btn-edit">Edit</a> <a class="btn-view" href="admin.php?page=student-system&action=view&id=' + student.id + '">View</a> <a class="btn-delete btn-student-delete" data-id="' + student.id + '">Delete</a></td>';
                            studentHTML += "</tr>";
                        });

                        $(".student-table tbody").html(studentHTML);
                    } else {
                        toastr.error(data.message);
                        // Clear the table if no students found
                        $(".student-table tbody").empty();
                    }
                } catch (e) {
                    console.error("Failed to parse JSON response:", e);
                    toastr.error('Failed to search students.');
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            }
        });
    }
// });

    // Function to update student table with new data
    function updateStudentTable(students) {
        var studentHTML = "";
        $.each(students, function(index, student) {
            studentHTML += "<tr>";
            studentHTML += "<td>" + student.id + "</td>";
            studentHTML += "<td>" + student.name + "</td>";
            studentHTML += "<td>" + student.email + "</td>";
            studentHTML += '<td><img style="height:100px;width:100px" src="' + student.profile_image + '"/></td>';
            studentHTML += "<td>" + student.gender + "</td>";
            studentHTML += "<td>" + student.phone_no + "</td>";
            studentHTML += '<td><a href="admin.php?page=student-system&action=edit&id=' + student.id + '" class="btn-edit">Edit</a> <a class="btn-view" href="admin.php?page=student-system&action=view&id=' + student.id + '">View</a> <a class="btn-delete btn-student-delete" data-id="' + student.id + '">Delete</a></td>';
            studentHTML += "</tr>";
        });

        $(".student-table tbody").html(studentHTML);
    }

});
